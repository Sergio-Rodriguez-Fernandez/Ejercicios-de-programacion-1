from guizero import App, Text

app = App(title="Hola ICI")

message =  Text(app,text="Welcome to ICI World")
app.display() 