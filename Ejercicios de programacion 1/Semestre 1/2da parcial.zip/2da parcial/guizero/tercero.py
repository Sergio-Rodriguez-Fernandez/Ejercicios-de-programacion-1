from guizero import App

app = App("Hola ICI")

app.display() 